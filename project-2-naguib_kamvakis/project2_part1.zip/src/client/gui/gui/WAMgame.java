package client.gui.gui;

import java.util.LinkedList;
import java.util.List;
import java.util.Random;


public class WAMgame {

private int rows;

private int columns;

private static int UPMIN = 3 ;
private static int UPMAX = 5;

private static int DOWNMIN = 2;
private static int DOWNMAX = 10;

private boolean status;


private boolean[][] board;

    /** the observers of this model */
private List<client.gui.gui.Observer<WAMgame>> observers;





public WAMgame(int rows, int columns){
    this.observers = new LinkedList<>();
    this.status = true;
    this.rows = rows;
    this.columns = columns;

    //Creates a 2D array of booleans to monitor the state of each mole. False is down, True is up. All moles start down
    this.board = new boolean[columns][rows];
    for(int col=0; col<columns; col++) {
        for(int row=0; row < rows; row++) {
            board[col][row] = false;
        }
    }
}

//currently unused, it's just an infinite loop
public void rungame(double clock){
    while(clock!=0) {
       int r = (int)(Math.random() * (rows));
       int c = (int)(Math.random() * (rows));


    }

}


public void addObserver(client.gui.gui.Observer<WAMgame> observer) {

    this.observers.add(observer);
    }

    /**
     * calls for observers to update their boards
     */
    private void alertObservers() {
        for (Observer o: this.observers ) {
            o.update(this);
        }
    }

    /**
     * Used to determine what picture to use for the button
     * @param c column of the mole
     * @param r row of the mole
     * @return the boolean value of the mole, signifying if it should be up or down
     */
    public boolean getMoleAt(int c, int r){
    return board[c][r];
}

    /**
     * changes the boolean value of a mole to true and notifies observers of a change
     * @param mole the id number of the mole that should be raised
     */
    public void moleUp(int mole){
    board[mole%columns][mole/columns] = true; //bless whoever came up with this formula
    alertObservers();
}

    /**
     * changes the boolean value of a mole to false and notifies observers of a change
     * @param mole the id number of the mole that should be lowered
     */
    public void moleDown(int mole){
    board[mole%columns][mole/columns] = false;
    alertObservers();
}

    /**
     * signals the end of the game, which will close the loop in the client
     */
    public void endGame(){
    this.status = false;
    alertObservers();
}

    /**
     * @return a boolean value representing whether or not the game is running
     */
    public boolean getStatus(){
    return this.status;
}


public void close() {
        alertObservers();
    }



}
