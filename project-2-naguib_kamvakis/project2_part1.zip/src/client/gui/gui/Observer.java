package client.gui.gui;

public interface Observer<Subject>  {


    void update(Subject subject);
}
