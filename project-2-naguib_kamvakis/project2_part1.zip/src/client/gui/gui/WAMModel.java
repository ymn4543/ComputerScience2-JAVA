package client.gui.gui;

public class WAMModel {
}
