package client.gui.gui;

import client.gui.WAMNetworkClient;
import com.sun.javafx.iio.ios.IosDescriptor;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.control.Label;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.application.Platform;
import server.WhackAMoleException;

import java.io.IOException;
import java.io.PrintStream;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;


public class WAMGUI extends Application implements Observer<WAMgame> {

    public WAMNetworkClient wamNetworkClient;
    public Button[] buttons;
    public Hashtable<Button, Integer> buttonMap;
    public BorderPane borderPane;
    public WAMgame board;
    private int rows;
    private int columns;

    @Override
    public  void init() {
        //Creating connection to server
        try {
            List<String> args = getParameters().getRaw();
            String hostname = args.get(0);
            int port = Integer.parseInt(args.get(1));
            this.wamNetworkClient = new WAMNetworkClient(hostname, port);
        } catch (IOException ea) {
            System.out.println("fail");
        }


        //Preliminary setup that allows the creation of button array. Also initializes the game
        try {
            wamNetworkClient.makeParams();
        }
        catch(IOException wam){
            System.out.println("Connection Failed");

        }

        System.out.println("check 2");

        System.out.println(wamNetworkClient.getRows());
        System.out.println(wamNetworkClient.getColumns());
        System.out.println(wamNetworkClient.getPlayer());
        System.out.println(wamNetworkClient.getId());



        //Creation of above-mentioned button array. Also stores the # of rows/columns for the scene setup
        this.rows = wamNetworkClient.getRows();
        this.columns = wamNetworkClient.getColumns();
        this.buttons = new Button[this.rows*this.columns];
        this.buttonMap = new Hashtable<>();
        System.out.println(wamNetworkClient.getReady());
        System.out.println("done");


    }



    public void start(Stage stage) {

            this.borderPane = new BorderPane();
            GridPane gridPane = new GridPane();
            gridPane.setGridLinesVisible(true);
            javafx.scene.image.Image image = new Image(getClass().getResourceAsStream("empty.png"));

            //places each button in the button array onto the gridPane, as well as storing it and its id in a hash table
            int buttonid = 0;
            for (int r = 0; r < rows; r++) {
                for (int c = 0; c < columns; c++) {
                    int col = c;
                    Button button = new Button();
                    button.setGraphic(new ImageView(image));
                    gridPane.add(button, c, r);
                    buttons[buttonid] = button;
                    buttonMap.put(button, buttonid);
                    buttonid++;

                    //applies behavior for when button is pushed
                    button.setOnAction(Event -> {
                                int x = buttonMap.get(button);
                                wamNetworkClient.whack(x);
                            }
                    );
                }
            }
            borderPane.setCenter(gridPane);
            gridPane.setAlignment(Pos.CENTER);
            Scene scene = new Scene(borderPane);
            stage.setTitle("WHACK-A-MOLE");
            this.board = wamNetworkClient.getBoard();
            this.board.addObserver(this);
            stage.setScene(scene);
            stage.show();
            System.out.println("show");


            wamNetworkClient.startListener();





    }

    public void run(){
        this.wamNetworkClient.run();
    }

    public void update(WAMgame waMgame) {
        if ( Platform.isFxApplicationThread() ) {
            this.refresh();
        }
        else {
            Platform.runLater( () -> this.refresh() );
        }
    }




    private void refresh() {
        javafx.scene.image.Image down = new Image(getClass().getResourceAsStream("empty.png"));
        javafx.scene.image.Image up = new Image(getClass().getResourceAsStream("mole.png"));

        //iterates over the buttons and changes the image to match the status of the buttons
        int b=0;
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < columns; c++) {
                Button button = buttons[b];
                boolean moleStatus = board.getMoleAt(c, r);
                if (moleStatus) {
                    button.setGraphic(new ImageView(up));
                }
                if (!moleStatus) {
                    button.setGraphic(new ImageView(down));
                }
                b++;
            }
        }
        }


    /**
     * closes server connection
     * @throws IOException
     */
    public void stop() throws IOException {
        wamNetworkClient.stop();
        wamNetworkClient.close();

    }


    public static void main(String[] args) {
        if (args.length != 2) {
            System.out.println(
                    "error");
            System.exit(1);
        }
        Application.launch(args);


    }
}
