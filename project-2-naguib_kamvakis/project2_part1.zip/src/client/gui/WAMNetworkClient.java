package client.gui;

import client.gui.gui.WAMGUI;
import client.gui.gui.WAMgame;
import common.WAMProtocol;
import javafx.application.Application;
import server.WhackAMoleException;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Arrays;
import java.util.NoSuchElementException;
import java.util.Scanner;
import static common.WAMProtocol.*;

public class WAMNetworkClient implements Runnable {

    /**
     * Controller
     */

    private Socket socket;
    private Scanner netIn;
    private PrintStream netOut;
    private InputStream in;
    private OutputStream out;
    private int rows;
    private int columns;
    private int player;
    private int id;
    private boolean go;
    private boolean ready;
    private Thread thread;
    private WAMGUI wamgui;
    private WAMgame board;


    public WAMNetworkClient(String host, int port) throws IOException {
        //Connects to the server and opens necessary I/OStreams
        this.socket = new Socket(host, port);
        this.in = socket.getInputStream();
        this.out = socket.getOutputStream();
        this.netIn = new Scanner(in);
        this.netOut = new PrintStream(out);
        this.go = true;
        this.ready = false;
        System.out.println("Connected to server " + this.socket);

    }

    public void startListener() {
        new Thread(() -> this.run()).start();
    }



    public void run(){
        while (go) {
            try {
                while (board.getStatus())//while the game is running
                {
                    String request = this.netIn.next();

                    System.out.println("Net message in = \"" + request + '"');
                    String arguments = this.netIn.nextLine().trim();
                    String[] arglist = arguments.split(" ");
                    switch (request) {

                            /*Same as makeParams, in case server sends WELCOME again. Might become an error later,
                            but should be fine for now
                             */
                        case WELCOME:
                            this.rows = Integer.parseInt(arglist[0]);
                            System.out.println("set rows to " + this.rows);
                            this.columns = Integer.parseInt(arglist[1]);
                            System.out.println("set columns to " + this.columns);
                            this.player = Integer.parseInt(arglist[2]);
                            System.out.println("set player to " + this.player);
                            this.id = Integer.parseInt(arglist[3]);
                            System.out.println("set id to " + this.id);
                            this.board = new WAMgame(rows, columns);
                            this.ready = true;
                            System.out.println("notified");
                            break;

                            //Server provides mole to be raised, tells board to raise that mole
                        case MOLE_UP:
                            int moleup = Integer.parseInt(arguments);
                            System.out.println("Mole up at " + moleup);
                            board.moleUp(moleup);
                            break;

                            //Server provides mole to be lowered, tells board to lower that mole
                        case MOLE_DOWN:
                            int moledown = Integer.parseInt(arguments);
                            board.moleDown(moledown);
                            System.out.println("Mole down at " + moledown);
                            break;

                        case WHACK:
                            break;

                        case SCORE:
                            break;

                            //The 3 different ways the game can end, currently all functionally the same
                        case GAME_WON:
                            board.endGame();
                            this.stop();
                            break;

                        case GAME_TIED:
                            board.endGame();
                            this.stop();
                            break;

                        case GAME_LOST:
                            board.endGame();
                            this.stop();
                            break;

                            //in case something happens with the server
                        case ERROR:
                            board.endGame();
                            this.stop();
                            break;

                        default:
                            System.err.println("Unrecognized request: " + request);
                    }
                }
            }
            catch(NoSuchElementException nse ){
                    // Looks like the connection shut down.
                    System.out.println(nse);
                    break;
                }
            catch(Exception e ){
                    System.out.println(e);
                    this.close();
                }


            }


        }


       // public Thread getThread(){
       // return Thread.currentThread();


    /**
     * Tells server when a mole has been clicked on so it can relay that data to the players
     * @param moleNumber the ID of the mole that was clicked on
     */
    public void whack(int moleNumber){
        netOut.println(WHACK + " " + moleNumber + " " + getId());
    }

    public void close(){
        try {
            this.board.close();
            this.stop();
            this.socket.close();
            socket.shutdownOutput();
            socket.shutdownInput();
        }
        catch (IOException io){
            System.out.println("error");
        }

    }

    /**
     * Use this method in the GUI class to receive the first message from the server, which contains the
     * information needed to create the board and buttons. Need to call this before the start method happens,
     * otherwise it'll instantiate a 0x0 double array
     */
    public void makeParams() throws IOException {
        if(go){
            String request = this.netIn.next();
            System.out.println("Net message in = \"" + request + '"');
            String arguments = this.netIn.nextLine().trim();
            String[] arglist = arguments.split(" ");
            System.out.println(Thread.currentThread());

            //Checking to make sure the request is the welcome, otherwise we have none of the numbers we need
            if (request.equals(WELCOME)) {
                this.rows = Integer.parseInt(arglist[0]);
                System.out.println("set rows to " + this.rows);
                this.columns = Integer.parseInt(arglist[1]);
                System.out.println("set columns to " + this.columns);
                this.player = Integer.parseInt(arglist[2]);
                System.out.println("set player to " + this.player);
                this.id = Integer.parseInt(arglist[3]);
                System.out.println("set id to " + this.id);
                this.ready = true;
                this.board = new WAMgame(rows,columns);
                System.out.println("notified");

            }

        }
        else{
            System.out.println("Error in communication with server: First request was not WELCOME");
        }
    }


    /**
     * @return the Wack-a-Mole board object being used
     */
    public WAMgame getBoard(){
        return this.board;
    }

    /**
     * @return boolean indicating whether or not client has been welcomed by the server and received necessary info
     */
    public boolean getReady(){
        return ready;
    }

    public void stop(){
        this.go = false;
    }

    /**
     * @return number of rows in the game board
     */
    public int getRows(){
            return this.rows;
    }

    /**
     * @return number of columns in the game board
     */
    public int getColumns(){
        return this.columns;
    }

    /**
     * @return the player number assigned by the server
     */
    public int getPlayer(){
        return this.player;
    }

    /**
     * @return
     */
    public int getId(){
        return this.id;
    }


}

