package server;

import common.WAMProtocol;

import java.io.IOException;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Scanner;

public class ClientHandler implements Runnable {
    private final Socket socket;
    private final Scanner scanner;
    private final PrintStream printer;


    public ClientHandler(Socket socket) throws IOException {
        this.socket = socket;
        scanner = new Scanner(socket.getInputStream());
        printer = new PrintStream(socket.getOutputStream());
    }

    @Override
    public void run() {
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.equals(WAMProtocol.ERROR)) {
                break;
            }
            if (line.equals(WAMProtocol.GAME_LOST)) {
                break;
            }
            if (line.equals(WAMProtocol.GAME_WON)) {
                break;
            }
            if (line.equals(WAMProtocol.GAME_TIED)) {
                break;
            }
            if (line.equals(WAMProtocol.GAME_TIED)) {
                break;
            }
            printer.println(line);
        }
        close();
    }


    public void close() {
        try {
            socket.shutdownOutput();
            socket.shutdownInput();
        }
        catch(IOException io){
            System.out.println(io);
        }
    }
}

