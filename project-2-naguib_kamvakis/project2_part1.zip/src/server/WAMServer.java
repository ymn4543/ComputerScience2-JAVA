package server;

import client.gui.gui.WAMGUI;
import client.gui.gui.WAMgame;
import common.WAMProtocol;
import common.WAMProtocol.*;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Random;
import java.util.Scanner;

public class WAMServer {

    private static int min = 1;
    private static int max = 5;
    private ServerSocket serverSocket;

    private Socket socket;

    private Scanner networkIn;

    private InputStream in;
    private OutputStream out;
    private PrintStream networkOut;


    public WAMServer(int port, int rows, int columns, int players, double runtime) throws IOException {
        this.serverSocket = new ServerSocket(port);



        }





    public void run(int rows, int columns, double clock){
        WAMgame board = new WAMgame(rows,columns);
        while(clock!=0){
            Random ran = new Random();
            int x = ran.nextInt(max) ;
            int y = ran.nextInt(max);
            int r = ran.nextInt(rows);
            int c = ran.nextInt(columns);
            int mole = r* c;
            networkOut.println();
        }


    }




    public static void main(String[] args){
        if (args.length != 5) {
            System.out.println(
                    "error");
            System.exit(1);
        }
        if(Integer.parseInt(args[3])<1){
            System.out.println(
                    "not enough players");
            System.exit(1);
        }

        int port = Integer.parseInt(args[0]);
        int rows = Integer.parseInt(args[1]);
        int columns = Integer.parseInt(args[2]);
        int players = Integer.parseInt(args[3]);
        double runtime = Double.parseDouble(args[4]);

        try {

            WAMServer wamServer = new WAMServer(port,rows,columns,players,runtime);
            //wamServer.run();
        }
        catch(IOException ea){
            System.out.println("fail");
        }
    }



}
