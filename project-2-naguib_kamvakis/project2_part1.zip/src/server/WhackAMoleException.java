package server;

public class WhackAMoleException extends Exception {

        public WhackAMoleException(String message) {
            super(message);
        }


        public WhackAMoleException(Throwable cause) {
            super(cause);
        }


        public WhackAMoleException(String message, Throwable cause) {

            super(message, cause);
        }
}
